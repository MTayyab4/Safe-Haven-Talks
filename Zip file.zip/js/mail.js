$(document).ready(function() {
    $('.newsletter').submit(function(e) {
        e.preventDefault();
        var email = $('#email').val();
        $.ajax({
            url: 'https://api.brevo.co/subscribe',
            method: 'POST',
            headers: {
                'X-Brevo-API-Key': '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'
            },
            data: {
                email: email
            },
            success: function(response) {
                $('#feedback-message').show();
                $('#message-text').text('Successful');
            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
            }
        });
    });
});
